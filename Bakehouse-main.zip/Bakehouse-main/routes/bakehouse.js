const path = require('path');

const express = require('express');

// const shopController = require('../controllers/shop');
const isAuth = require('../middleware/is-bakehouse');

const router = express.Router();

// routes

module.exports = router;
