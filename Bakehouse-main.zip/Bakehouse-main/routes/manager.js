const path = require('path');

const express = require('express');

const managerController = require('../controllers/manager');
const isAuth = require('../middleware/is-manager');

const router = express.Router();

router.get('/user', isAuth, managerController.getUsers);

module.exports = router;
