const User = require('../models/user');
const path = require('path');


const ITEMS_PER_PAGE = 5;

exports.getUsers = (req, res, next) => {
    const page = +req.query.page || 1;
    let totalItems;
  
    User.find()
      .countDocuments()
      .then(numUsers => {
        totalItems = numUsers;
        return User.find()
          .skip((page - 1) * ITEMS_PER_PAGE)
          .limit(ITEMS_PER_PAGE);
      })
      .then(users => {
        res.render('management/user', {
          users,
          pageTitle: 'Users',
          path: '/user',
          currentPage: page,
          hasNextPage: ITEMS_PER_PAGE * page < totalItems,
          hasPreviousPage: page > 1,
          nextPage: page + 1,
          previousPage: page - 1,
          lastPage: Math.ceil(totalItems / ITEMS_PER_PAGE)
        });
      })
      .catch(err => {
        const error = new Error(err);
        error.httpStatusCode = 500;
        return next(error);
      });
  };
  